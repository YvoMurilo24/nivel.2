let receitas = [ //JSON
  {
      "titulo": "Arroz de Couve-Flor",
      "imagem": "/json/arroz de couve flor .png.png",
      "ingredientes": ['Arroz',
      'Couve-Flor',
      'Cebola Media',
      'Azeite',
      'Sal'],
      "preparo": "Deixe a couve-flor picada, adicione os ingredientes e refogue bem, adicione sal, tampe a panela e deixe cozinhar.",
  },
  {
      "titulo": "Bolo de Café",
      "imagem": "/json/bolo-de-cafe .png.png",
      "ingredientes": ['Farinha de Trigo',
      'Açúcar',
      'Café Coado',
      'Chocolate em Pó',
      'Ovos'],
      "preparo": "Bata o açúcar, as gemas e o café, adicione farinha e chocolate e mexa bem, bata as claras e junte a mistura."
  },
  {
    "titulo": "Coxinha de Brigadeiro",
    "imagem": "/json/coxinha de brigadeiro.png.png",
    "ingredientes": ['Leite COndensado',
    'Chocolate em Pó',
    'Manteiga',
    'Morango',
    'Chocolate Granulado'],
    "preparo": "Junte o leite condensado, chocolate em pó e manteiga, aqueça no fogo baixo, envolva os morangos e passe no granulado"
}
]

function getListaIngredientes(receita) {
   var lista = "<ul>";
    lista += receita.ingredientes.map(ingrediente => `<li>${ingrediente}</li>`).reduce((acumulador,item) => acumulador + item );
    lista += "</ul>";
    return lista;
}

  


function getCard(receita) {
 let card =`
 
     <div class="card" style="width: 400px;">
     <img src='${receita.imagem}' class='card-img-top'>
     <div class="card-body">
     <h5 class='card-title text-center fs-4 p-2 fw-bold'>${receita.titulo}</h5>
     <div class='card-text'>${getListaIngredientes(receita)}</div>
     <hr>
     <p class="card-text p-2">${receita.preparo}</p>
     </div>
     </div>`
   return card
 }

                    
 function preencheCatalogo() {
    var catalogo = document.getElementById("pnlCatalogo");
    let html = receitas.map(getCard).reduce((acumulador,item) => acumulador+item);
    catalogo.innerHTML = html;
  }
  onload = preencheCatalogo()